<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="assign 1" />
    <meta name="keywords" content="PHP, Job Vacancy, Form" />
    <meta name="author" content="Mai Tien Dat Tran" />
    <link rel="stylesheet" href="style.css">

    <title>Post Job Vacancy Pages</title>
</head>
<body>
    <!-- Navigation bar -->
    <nav>
        <ul class="menu">
            <li class="nav-item"><a href="index.php">Home</a></li>
            <li class="nav-item"><a href="postjobform.php">Post Job</a></li>
            <li class="nav-item"><a href="searchjobform.php">Search Job</a></li>
            <li class="nav-item"><a href="about.php">About This Assignment</a></li>
        </ul>
    </nav>

    <?php
    // Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get data from form
    $positionIDD = trim($_POST['positionIDD']);
    $jobtitle = trim($_POST['jobtitle']);
    $descriptions = trim($_POST['descriptions']);
    $closingDates = trim($_POST['closingDates']);
    $jobTypes = isset($_POST['jobTypes']) ? trim($_POST['jobTypes']) : '';
    $contractTypes = isset($_POST['contractTypes']) ? trim($_POST['contractTypes']) : '';
    $locations = isset($_POST['locations']) ? trim($_POST['locations']) : '';
    $applicationMethoded = isset($_POST['applicationMethoded']) ? implode(", ", $_POST['applicationMethoded']) : "";

    // File to store job vacancies
    $file = "../../data/job/positions.txt"; // Correct variable name used

    $errors = [];

    // Check Position ID must be in format "IDxxx"
    if (!preg_match('/^ID[0-9]{3}$/', $positionIDD)) {
        $errors[] = "Position ID must follow the format IDxxx (e.g., ID008).";
    }

    // Check job title limit
    if (strlen($jobtitle) > 10) {
        $errors[] = "Job title must be 10 characters or less.";
    }

    // Check job description limit
    if (strlen($descriptions) > 250) {
        $errors[] = "Job description must be 250 characters or less.";
    }


 //Check CLosing date
 if (!preg_match('/^\d{1,2}\/\d{1,2}\/\d{2}$/', $closingDates)) {
    $errors[] = "The close date must be in 'dd/mm/yy' format.";
}

//Check the validity of this radio button

if (empty($jobTypes)) {
        $errors[] = "Please select a job type (Full-time or Part-time).";
    }

     // Check if contract type is selected
     if (empty($contractTypes)) {
        $errors[] = "Please select a contract type (Ongoing or Fixed-term).";
    }

        // Check if location is selected
        if (empty($locations)) {
            $errors[] = "Please select a location (On-site or Remote).";
        }

            // Check if application method is selected
    if (empty($applicationMethoded)) {
        $errors[] = "Please select at least one application method (Post or Email).";
    }
    

// Check if the position code already exists in positions.txt
if (file_exists($file)) {  // Use correct variable $file
    $fileContent = file_get_contents($file);
    
    // Check if $positionIDD is not empty before using strpos
    if (!empty($positionIDD) && strpos($fileContent, $positionIDD) !== false) {
        $errors[] = "Position ID already exists. Please use a different ID.";
    }
}




    // If there is an error, display an error message
    if (!empty($errors)) {
        echo "<h3>Error(s):</h3><ul>";
        foreach ($errors as $error) {
            echo "<li>$error</li>";
        }
        echo "</ul>";
        echo '<p><a href="postjobform.php">Go back to the form</a></p>';
    } else {
        // No errors, proceed to save data to positions.txt

        // Data to be saved
        $jobData = "$positionIDD\t$jobtitle\t$descriptions\t$closingDates\t$jobTypes\t$contractTypes\t$locations\t$applicationMethoded\n";

        // Save job data to file
        function saveJobsVacancy($file, $data) {
            // Check if the directory exists, if not, create it with appropriate permissions
            $dir = dirname($file);
            if (!is_dir($dir)) {
                if (!mkdir($dir, 0777, true)) { // 0777 gives full permissions (adjust for production)
                    die("Failed to create directory: " . $dir); // Exit if directory creation fails
                }
            }

            // Append the job data to the file
            if (file_put_contents($file, $data, FILE_APPEND) === false) {
                die("Error writing to file: " . $file); // Exit if writing to file fails
            } else {
                echo "Job vacancy successfully saved!";
            }
        }

        // Call the function to save the job data
        saveJobsVacancy($file, $jobData);

        // Show success message
        echo "<h3>Job Posted Successfully!</h3>";
        echo "<p>Job details have been saved.</p>";
        echo '<p><a href="index.php">Go back to Home</a></p>';
    }
} else {
    // If not POST method, show an error
    echo "<p>Invalid request. Please submit the form.</p>";
    echo '<p><a href="postjobform.php">Go back to the form</a></p>';    
}
    ?>
</body>
</html>
