<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <meta name="author" content="Mai Tien Dat Tran" />


    <title>Search Job Results</title>
</head>
<body>

 <!-- Navigation bar -->
 <nav>
    <ul class="menu">
      <li class="nav-item"><a href="index.php">Home</a></li>
      <li class="nav-item"><a href="postjobform.php">Post Job</a></li>
      <li class="nav-item"><a href="searchjobform.php">Search Job</a></li>
      <li class="nav-item"><a href="about.php">About This Assignment</a></li>
    </ul>
  </nav>

  <h1>Search Job Results</h1>
<?php

if ($_SERVER["REQUEST_METHOD"] == "GET") {

// Get search data from form

$jobTitle = isset($_GET['jobsname']) ? trim($_GET['jobsname']) : "";
$position = isset($_GET['positions']) ? trim($_GET['positions']) : "";
$contract = isset($_GET['contracts']) ? trim($_GET['contracts']) : "";
$applicationMethod = isset($_GET['via']) ? $_GET['via'] : [];
$location = isset($_GET['locations']) ? trim($_GET['locations']) : "";
// archive file

$file = "../../data/job/positions.txt";
// Check if positions.txt file exists

if (file_exists($file)) {
    // Read positions.txt file
    $fileHandle  = fopen($file, "r");
    $resultsFound = false; //Variable to track whether any results were found

    echo "<h2>Matching Job Vacancies:</h2>";

    //Browse each line of the file positions.txt
    while (($line = fgets($fileHandle)) !== false) {
        // Split rows into tab-based sections (since fields are tab-separated)
        list($id, $title, $description, $closingDate, $jobType, $contractType, $jobLocation, $applicationTypes) = explode("\t", trim($line));

        // Check each search condition
        if ((empty($jobTitle) || stripos($title, $jobTitle) !== false) &&
                (empty($position) || $position == $jobType) &&
                (empty($contract) || $contract == $contractType) &&
                (empty($location) || $location == $jobLocation) &&
                (empty($applicationMethod) || count(array_intersect($applicationMethod, explode(", ", $applicationTypes))) > 0)) {


            // Show work results
            echo "<div class='job-listing'>";
            echo "<strong>Position ID:</strong> $id<br>";
            echo "<strong>Title:</strong> $title<br>";
            echo "<strong>Description:</strong> $description<br>";
            echo "<strong>Closing Date:</strong> $closingDate<br>";
            echo "<strong>Job Type:</strong> $jobType<br>";
            echo "<strong>Contract Type:</strong> $contractType<br>";
            echo "<strong>Location:</strong> $jobLocation<br>";
            echo "<strong>Application Methods:</strong> $applicationTypes<br>";
            echo "</div><hr>";
            
            $resultsFound = true;
        }
    }
    fclose($fileHandle);

    // If no results found

    if (!$resultsFound) {
        echo "<p>No matching job vacancies found for your search criteria.</p>";
    }
} else {
    // Alert if positions.txt file does not exist
    echo "<p>Error: The job vacancies file does not exist.</p>";
}
} else {
echo "<p>Error: Invalid request method.</p>";
}



?>

<!-- Link back to search page -->
<p><a href="searchjobform.php">Go back to Search</a></p>

<!-- Link back to home page-->
<p><a href="index.php">Back to Home</a></p>
    
</body>
</html>