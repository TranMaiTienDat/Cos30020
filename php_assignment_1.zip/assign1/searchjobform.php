<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Mai Tien Dat Tran" />
    <link rel="stylesheet" href="style.css">

    <title>Search Job Form</title>
</head>
<body>

  <!-- Navigation bar -->
  <nav>
    <ul class="menu">
      <li class="nav-item"><a href="index.php">Home</a></li>
      <li class="nav-item"><a href="postjobform.php">Post Job</a></li>
      <li class="nav-item"><a href="searchjobform.php">Search Job</a></li>
      <li class="nav-item"><a href="about.php">About This assignment</a></li>
    </ul>
  </nav>

  <h1>Job Vacancy Posting System</h1>

  <form action="searchjobprocess.php" method="get">
<!-- job title -->
  <label for="jobsname">Job Title: </label>
  <input type="text" id="jobsname" name="jobsname" placeholder="Enter Job Title">
  <!-- Form Section for Job Posting -->
<div class="form-select">
    <!-- Position Dropdown -->
    <label for="positions"><strong>Position:</strong></label>
    <select id="positions" name="positions" >
        <option value="">Select Position</option> <!-- Updated the placeholder option for clarity -->
        <option value="Full-time">Full-time</option>
        <option value="Part-time">Part-time</option>
    </select><br>
</div>

<div class="form-select">
    <!-- Contract Dropdown -->
    <label for="contracts"><strong>Contract Type:</strong></label>
    <select id="contracts" name="contracts" >
        <option value="">Select Contract Type</option> <!-- Updated for clarity -->
        <option value="Ongoing">Ongoing</option>
        <option value="Fixed-term">Fixed-term</option>
    </select><br>
</div>

<div class="form-checkbox">
    <!-- Application Type (Post or Email) -->
    <label><strong>Application Type:</strong></label><br>
    <input type="checkbox" id="appPost" name="via[]" value="Post">
    <label for="appPosts">Post</label>
    <input type="checkbox" id="appEmail" name="via[]" value="Email">
    <label for="appEmails">Email</label><br>
</div>

<div class="form-select">
    <!-- Location Dropdown -->
    <label for="locations"><strong>Location:</strong></label>
    <select id="locations" name="locations" >
        <option value="">Select Location</option> <!-- Clearer option label -->
        <option value="On-site">On-site</option>
        <option value="Remote">Remote</option>
    </select><br>
</div>

<input type="submit" value="Search"> <br>

<button onclick="window.location.href='index.php'" class="buttonbackhome">Home</button>


    
</body>
</html>