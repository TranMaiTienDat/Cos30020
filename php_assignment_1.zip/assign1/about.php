<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Assignment 1 - About Page" />
    <meta name="keywords" content="PHP, About Assignment" />
    <meta name="author" content="Mai Tien Dat Tran" />
    <link rel="stylesheet" href="style.css">
    <title>About This Assignment</title>
</head>
<body>
    <!-- Navigation bar -->
    <nav>
        <ul class="menu">
            <li class="nav-item"><a href="index.php">Home</a></li>
            <li class="nav-item"><a href="postjobform.php">Post Job</a></li>
            <li class="nav-item"><a href="searchjobform.php">Search Job</a></li>
            <li class="nav-item"><a href="about.php">About This Assignment</a></li>
        </ul>
    </nav>

    <h1>About This Assignment</h1>

    <h2>Task 6 - Questions and Answers</h2>

    <h3>1. PHP Version Installed on Mercury</h3>
    <ul>
        <li><?php echo 'PHP Version: ' . phpversion(); ?></li>
    </ul>

    <h3>2. Tasks Not Attempted or Not Completed</h3>
    <ul>
        <li>I have completed most of the tasks. except task 8</li>
    </ul>

    <h3>3. Special Features Attempted</h3>
    <ul>
        <li>I have implemented form validation to ensure users provide valid input when posting jobs.</li>
        <li>Jobs are stored in a file system, with a structured format that makes data easy to search and retrieve.</li>
        <li>The search function allows filtering of jobs based on various criteria such as job title, contract type, location and application method.</li>
    </ul>

    <h2>Task 6 - Discussion Board Participation</h2>
    <ul>
        <li>I did not participate in the unit’s discussion board for Assignment 1 due to time constraints and focusing on completing the assignment.</li>
    </ul>

    <h2>Return to Home Page</h2>
    <p><a href="index.php">Go back to Home</a></p>
</body>
</html>
