<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="des" content="assign 1" />
<meta name="keywords" content="PHP, Job Vacancy, Form" />
<meta name="author" content="Mai Tien Dat Tran" />
<link rel="stylesheet" href="style.css">

    <title>Post Job Vacancy Pages</title>
</head>
<body>
     <!-- Navigation bar -->
  <nav>
    <ul class="menu">
      <li class="nav-item"><a href="index.php">Home</a></li>
      <li class="nav-item"><a href="postjobform.php">Post Job</a></li>
      <li class="nav-item"><a href="searchjobform.php">Search Job</a></li>
      <li class="nav-item"><a href="about.php">About This assignment</a></li>
    </ul>
  </nav>
  <h1>Post Job Vacancy</h1>
  <form action="postjobprocess.php" method="POST">
     <!-- Position ID Input -->
  <label for="positionIDD">Position ID (format: ID001):</label>
        <input type="text" id="positionIDD" name="positionIDD"><br>
          <!-- Job Title Input -->

          <label for="jobtitle">Job Title (max 10 characters):</label>
          <input type="text" id="jobtitle" name="jobtitle" ><br>

           <!-- Job Description Text Area -->

           <label for="descriptions">Job Description (max 250 characters):</label>
        <textarea id="descriptions" name="descriptions"  rows="5" ></textarea><br>

         <!-- Closing Date Input -->

         <label for="closingDates">Closing Date:</label>
<input type="text" id="closingDates" name="closingDates" value="<?php echo date('d/m/y'); ?>"> <br>

                <!-- Position Type Radio Buttons -->

                <label for="jobTypes">Job Type:</label>
        <input type="radio" id="fullTime" name="jobTypes" value="Full-time" > 
        <label for="fullTimejobs">Full-time</label>
        <input type="radio" id="partTime" name="jobTypes" value="Part-time"> 
        <label for="partTimejobs">Part-time</label><br>

       <!-- Contract Type as Radio Buttons -->
<label for="contractTypes">Contract Type:</label>
<input type="radio" id="ongoing" name="contractTypes" value="Ongoing" > 
<label for="ongoing">On-going</label>

<input type="radio" id="fixedTerm" name="contractTypes" value="Fixed-term">
<label for="fixedTerm">Fixed-term</label><br>
                <!-- Location -->

        <label for="locations">Location:</label>
        <input type="radio" id="onSite" name="locations" value="On-site" > 
        <label for="onSite">On-site</label>
        <input type="radio" id="remote" name="locations" value="Remote"> 
        <label for="remote">Remote</label><br>
                <!-- Apply apllycation -->
                <label for="applicationMethoded">Application Method:</label>
        <input type="checkbox" id="post" name="applicationMethoded[]" value="Post"> 
        <label for="post">Post</label>
        <input type="checkbox" id="email" name="applicationMethoded[]" value="Email"> 
        <label for="email">Email</label><br>
                <!-- submit -->

                <input type="submit" value="Submit Job"> <br>
                </form>

                <button onclick="window.location.href='index.php'" class="buttonbackhome">Home</button>

    
</body>
</html>