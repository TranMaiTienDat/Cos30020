<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="des" content="assign 1" />
<meta name="keywords" content="PHP, Job Vacancy, Form" />
<meta name="author" content="Mai Tien Dat Tran" />
  <title>Job Vacancy System by [Mai Tien Dat Tran]</title>
  <!-- Link to custom stylesheet -->
  <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
  <!-- Main header section -->
  <h1 class="header">Job Vacancy Posting System</h1>
  
  <!-- Navigation bar -->
  <nav>
    <ul class="menu">
      <li class="nav-item"><a href="index.php">Home</a></li>
      <li class="nav-item"><a href="postjobform.php">Post Job</a></li>
      <li class="nav-item"><a href="searchjobform.php">Search Job</a></li>
      <li class="nav-item"><a href="about.php">About This assignment</a></li>
    </ul>
  </nav>

  <!-- Main content section -->
  <div class="container">
  <div class="row">
    <div class="col-25">
      <p>Name: <span>Mai Tien Dat Tran</span></p>
    </div>
  </div>

  <div class="row">
    <div class="col-25">
      <p>Student ID: <span>104207944</span></p>
    </div>
  </div>

  <div class="row">
    <div class="col-25">
      <p>Email: <span><a href="mailto:104207944@student.swin.edu.au">104207944@student.swin.edu.au</a></span></p>
    </div>
  </div>

    <!-- Declaration of originality -->
    <div class="row">
      <p class="declare">I declare that this assignment is my individual work. I have not worked collaboratively nor have I copied from any other student’s work or any other source.</p>
    </div>

    <div class="push"></div>
  </div>

  <!-- Footer section -->
  <footer class="footer">
    <p>&copy; 2024 Mai Tien Dat Tran. All rights reserved.</p>
  </footer>
</body>

</html>
